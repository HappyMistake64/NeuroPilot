'use strict';
const $=id=>document.getElementById(id);
async function api(path,body){const r=await fetch('/rsi/api/'+path,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw Error(data.error||r.status);return data;}
function el(tag,text){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;}
function button(text,fn,style='secondary'){const n=el('button',text);n.className=style;n.onclick=async()=>{n.disabled=true;try{await fn();$('message').textContent='';await refresh();}catch(e){$('message').textContent=e.message;}finally{n.disabled=false;}};return n;}
function showReport(run){
 const report=run.report||run;
 $('report').textContent=JSON.stringify(run,null,2);
 let text=`Stav: ${report.status||run.status||'neznámý'}. `;
 if(report.pilot_capability_gain_confirmed)text+='Potvrzen přínos schopností v pilotu. ';
 if(report.pilot_efficiency_gain_confirmed)text+='Potvrzena úspora tokenů při stejných výsledcích. ';
 if(report.kind==='study')text+=report.audit_complete?'A/B audit dokončen; jde o jedno pilotní srovnání. ':'A/B audit není dokončen. ';
 if(report.actual_rsi_improvement_proven===false)text+='Obecný přínos RSI není prokázán.';
 $('outcome').textContent=text;
}
let polling=false;
async function refresh(){if(polling)return;polling=true;try{const data=await api('status');$('study_plan').textContent=data.study_plan?JSON.stringify(data.study_plan,null,2):'Nejdřív připrav A/B plán.';
$('limits').textContent=`Limity jedné větve: ${data.limits.max_calls} volání, ${data.limits.max_tokens} tokenů, ${data.limits.max_seconds} sekund. Brána úspory: ${data.gates.allow_efficiency?data.gates.min_token_saving_percent+' %':'vypnutá'}.`;
$('active').textContent=data.active||'Nepřipraveno';$('job').textContent=JSON.stringify(data.job,null,2);$('benchmark').textContent=data.benchmark?`Úlohy: ${JSON.stringify(data.benchmark.counts)} · ${data.benchmark.kind}`:'Úlohy ještě nejsou připravené.';
$('versions').replaceChildren(...data.artifacts.map(a=>{const row=el('tr');for(const value of[a.id,a.parent||'—',a.status,a.hypothesis])row.append(el('td',value));const cell=el('td');cell.append(button('Zobrazit změnu',async()=>{const item=await api('artifact/'+encodeURIComponent(a.id));$('report').textContent=item.diff||'Beze změny';$('outcome').textContent=item.hypothesis;}));if(a.status==='accepted'&&a.id!==data.active)cell.append(button('Použít verzi',()=>api('job',{kind:'activate',artifact:a.id})));row.append(cell);return row;}));
$('runs').replaceChildren(...data.runs.map(r=>{const line=el('div');line.append(button(`${r.kind} · ${r.status} · ${r.id}`,async()=>{showReport(await api('run/'+encodeURIComponent(r.id)));}));if(r.status==='running')line.append(button('Zastavit',()=>api('stop/'+encodeURIComponent(r.id),{}),'danger'));return line;}));
}finally{polling=false;}}
for(const kind of['init','doctor','baseline','campaign','rollback','study_prepare','study']){$(kind).onclick=async()=>{$(kind).disabled=true;try{if(kind==='rollback'&&!confirm('Vrátit předchozí verzi RSI agenta?'))return;await api(kind==='init'?'init':'job',kind==='init'?{}:{kind});await refresh();}catch(e){$('message').textContent=e.message;}finally{$(kind).disabled=false;}};}
refresh().catch(e=>{$('message').textContent=e.message;});setInterval(()=>refresh().catch(e=>{$('message').textContent=e.message;}),2000);
