// Real-server DOM test; does not assert model capability or graphical rendering.
const {JSDOM, VirtualConsole}=require('jsdom');
const {spawn}=require('node:child_process');
const {mkdtempSync,rmSync}=require('node:fs');
const {tmpdir}=require('node:os');
const path=require('node:path');
const net=require('node:net');
const assert=require('node:assert/strict');
async function waitFor(fn){const end=Date.now()+15000;while(Date.now()<end){if(await fn())return;await new Promise(r=>setTimeout(r,30));}throw Error('UI timeout');}
(async()=>{
 const temp=mkdtempSync(path.join(tmpdir(),'neuropilot-rsi-dom-'));
 const socket=net.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));const base=`http://127.0.0.1:${port}`;
 const child=spawn(process.env.PYTHON||'python3',['-c',`import server; server.app.run(host='127.0.0.1',port=${port},debug=False)`],{cwd:path.resolve(__dirname,'..'),env:{...process.env,NEUROPILOT_DATA:path.join(temp,'data.json'),NEUROPILOT_RSI_STATE:path.join(temp,'rsi')},stdio:'ignore'});
 let dom;
 try{
 await waitFor(async()=>{try{return(await fetch(base+'/health')).ok}catch{return false}});
 const errors=[];const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
 dom=await JSDOM.fromURL(base+'/rsi',{resources:'usable',runScripts:'dangerously',virtualConsole:vc,beforeParse(w){w.fetch=(u,o)=>fetch(new URL(u,base),o);w.confirm=()=>true;}});
 const $=id=>dom.window.document.getElementById(id);
 await waitFor(()=>$('init')?.onclick);$('init').click();
 await waitFor(()=>$('active').textContent.startsWith('agent-'));
 assert.equal(dom.window.document.querySelectorAll('#versions tr').length,1);
 assert.match($('benchmark').textContent,/20/);
 dom.window.document.querySelector('#versions button').click();
 await waitFor(()=>$('report').textContent.includes('build_context'));
 $('study_prepare').click();
 await waitFor(()=>$('study_plan').textContent.includes('770'));
 assert.match($('limits').textContent,/15 %/);
 $('doctor').click();
 await waitFor(()=>$('job').textContent.includes('"ready": false'));
 assert.match($('job').textContent,/Set model/);
 $('baseline').click();
 await waitFor(()=>$('runs').textContent.includes('blocked'));
 dom.window.document.querySelector('#runs button').click();
 await waitFor(()=>$('report').textContent.includes('"status": "blocked"'));
 $('study').click();
 await waitFor(()=>$('runs').textContent.includes('study · blocked'));
 assert.deepEqual(errors,[]);
 process.stdout.write('PASS RSI DOM: initialization, active artifact, benchmark counts, source diff, A/B plan, budget display, blocked environment/baseline/study, no JS errors.\n');
 }finally{dom?.window.close();child.kill();rmSync(temp,{recursive:true,force:true});}
})().catch(e=>{process.stderr.write(e.stack+'\n');process.exitCode=1});
